import os, json
import subprocess
def save_json(fname, data):
    create_dirs(fname)
    with open(fname, "w") as json_file:
        json.dump(data, json_file, indent=4, sort_keys=True)

    print("Saved %s" % fname)

def run_bash_command(command, noSplit=True):
    if noSplit:
        command = command.split()
    process = subprocess.Popen(command, stdout=subprocess.PIPE)
    output, error = process.communicate()

    return str(output)

def load_json(fname):
    with open(fname, "r") as json_file:
        d = json.load(json_file)
    
    return d
def extract_fname(directory):
    import ntpath
    return ntpath.basename(directory)

def create_dirs(fname):
    if "/" not in fname:
        return
        
    if not os.path.exists(os.path.dirname(fname)):
        try:
            os.makedirs(os.path.dirname(fname))
        except OSError:
            pass     

fig_root = "/home/issam/Summaries/manSAGA/Saves"

root = "/mnt/home/issam/Summaries/manSAGA/"
def get_fig_path(exp_name):
    return root + "/Figures/%s.png" % exp_name

def get_exp_path(dataset_name, model_name, learning_rate, epochs,sampling_method):
    exp_name = "%s_%s_%s_%s" % (dataset_name, model_name, str(learning_rate), sampling_method)
    return root + "/Saves/%s.json" % exp_name