
import matplotlib
matplotlib.use('Agg')

import math
import torch
from matplotlib import pyplot as plt
import numpy as np
import numpy.random as npr
from scipy.stats import (multivariate_normal, norm, invwishart, )
from scipy.linalg import (sqrtm, )
from sklearn.utils import shuffle
import models as mo
import datasets as da
from torch.utils import data
import argparse
import torch.nn as nn
import models
from torch.autograd import Variable
import main
import pylab as plt
from itertools import product
import pretty_plot
import utils as ut
import pandas as pd
import sphere as sp
import datasets as da
import borgy_utils as bu 
import os 
s2s = {"uniform":"U", "lipschitz":"NU"}

def get_best():
        scores = []
        for d, m, e, l, s in product(dList, mList, eList, lList, sList):
                fname = ut.get_exp_path(d, m, l, e, s)
                if not os.path.exists(fname):
                    print("Skipped in %s" % fname)
                else:
                    history = pd.DataFrame(ut.load_json(fname)["loss"])
                    scores += [{"d":d,
                                "method":"%s_1e%d (%s)" % (m, int(np.log(l)/np.log(10)), s2s[s]),
                                "loss":np.array(history["loss"])[-1], 
                                "epoch":np.array(history["epoch"])[-1],
                                "fname":fname}]
        if len(scores) > 0:
            print()
            df = pd.DataFrame(scores)

            best_scores = []
            for i in ["saga", "svrg", "sgd"]:
                for j in ["U", "NU"]:
                    import ipdb; ipdb.set_trace()  # breakpoint 046fd311 //
                    
                    rr = df[(df['method'].str.contains(i)) & (df['method'].str.contains(j))].sort_values(
                        by=['loss'],ascending=True)

                    best_scores += [dict(rr.iloc[0])]
            #print(df.sort_values(by=['loss'],ascending=False))
            return best_scores
            


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('-e','--experiment', default="A") 
    parser.add_argument('-m','--mode') 
    parser.add_argument('-r','--reset', default=0, type=int) 
    args = parser.parse_args()



    if args.experiment == "A":
        dList = ["A"]
        mList = ["svrg", "saga", "sgd"]
        eList = [100]
        lList = [1e1, 1.0, 1e-1,1e-2,1e-3,1e-4, 1e-5, 1e-6, 1e-7, 1e-8, 1e-9]
        sList = ["uniform"]

    if args.experiment == "A1":
        dList = ["A"]
        mList = ["saga", "sgd", "svrg"]
        eList = [200]
        lList = [1e-9]
        sList = ["uniform", "lipschitz"]

    if args.experiment == "M":
        dList = ["M"]
        mList = ["saga", "sgd", "svrg"]
        eList = [200]
        lList = [1e-5, 1e-6, 1e-7, 1e-8]
        sList = ["uniform", "lipschitz"]

    if args.experiment == "M1":
        dList = ["M1", "M2", "M3", "M4"]
        mList = ["saga", "sgd", "svrg"]
        eList = [200]
        lList = [1e1, 1.0, 1e-1,1e-2,1e-3,1e-4, 1e-5, 1e-6, 1e-7, 1e-8, 1e-9]
        sList = ["uniform", "lipschitz"]


    if args.experiment == "svrg":
        dList = ["M1", "M2", "M3", "M4"]
        mList = ["saga", "sgd", "svrg"]
        eList = [100]
        lList = [1e-5, 1e-6, 1e-7, 1e-8]
        sList = ["uniform", "lipschitz"]

    if args.experiment == "B":
        dList = ["B"]
        mList = ["saga", "sgd", "svrg"]
        eList = [500]
        lList = [1e-5, 1e-6, 1e-7, 1e-8]
        sList = ["uniform", "lipschitz"]

    filterme= True
    if args.mode == "borgy":
        for d, m, e, l, s in product(dList, mList, eList, lList, sList):
            fname = ut.get_exp_path(d, m, l, e, s)
            if not os.path.exists(fname) or args.reset:
                ver = bu.run(dataset_name=d, model_name=m,
                       epochs=e, learning_rate=l, sampling_method=s)
                print("%s in %s\n" % (ver, fname))
            else:
                print("Exists in %s" % fname)

    # if args.mode == "best":
    #     for d, m, e, l, s in product(dList, mList, eList, lList, sList):
    #          fname = ut.get_exp_path(d, m, l, e, s)
    #             if not os.path.exists(fname):
    #                 print("Skipped in %s" % fname)
    #             else:
    #                 history = pd.DataFrame(ut.load_json(fname)["loss"])

    if args.mode == "mnist":
        for label in [1,2,3,4,5,6]:
            Z = da.M(label=label)
            V = sp.largest_eigen(Z)
            plt.imshow(V.reshape((28,28)))
            plt.savefig("/home/issam/Summaries/manSAGA/MNIST/%d.png" % label)


    if args.mode == "train":
        for d, m, e, l, s in product(dList, mList, eList, lList, sList):
            fname = ut.get_exp_path(d, m, l, e, s)
            if not os.path.exists(fname)  or args.reset:
                main.run(dataset_name=d, model_name=m,
                 epochs=e, learning_rate=l, sampling_method=s)
            else:
                print("Exists in %s" % fname)

    if args.mode == "summary":

        best_scores = get_best()
        #print(df.sort_values(by=['loss'],ascending=False))
        print(pd.DataFrame(best_scores))
                
    if args.mode == "plot":
        best_scores = get_best()
        n_plots = 0
        n_done = 0
        ncols = len(dList)
        nrows = 1
        pp_main = pretty_plot.PrettyPlot(title="Experiment %s" % args.experiment, 
                                    ratio=0.5,
                                    legend_type="line",
                                    yscale="log",
                                    shareRowLabel=False,
                                    figsize=(5*ncols,4*1),
                                    subplots=(nrows, ncols))
        for d in dList:
            for m, e, l, s in product(mList, eList, lList, sList):
                fname = ut.get_exp_path(d, m, l, e, s)

                if fname not in np.array(pd.DataFrame(best_scores)["fname"]):
                    continue
                n_plots += 1
                if not os.path.exists(fname):
                    print("Skipped in %s" % fname)
                   
                    continue
                n_done += 1
                history = pd.DataFrame(ut.load_json(fname)["loss"])

                pp_main.add_yxList(y_vals=np.abs(history["loss"]), 
                                   x_vals=history["epoch"], 
                                   label="%s_$10^{-%s}$ (%s)" % (m,str(l)[-1], s2s[s]))

            pp_main.plot(ylabel="$f(x) - f^*$ on Dataset %s" % d, 
                         xlabel="Epochs",
                         yscale="log")


        pp_main.fig.tight_layout(rect=[0, 0.03, 1, 0.95])
        figName = ut.get_fig_path(args.experiment )
        ut.create_dirs(figName)
        pp_main.fig.savefig(figName, dpi = 600)
        print("plots: %d/%d" % (n_done, n_plots))


