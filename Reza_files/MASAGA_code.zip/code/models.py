import torch
import torchvision
import torchvision.transforms as transforms
from torch.autograd import Variable, grad
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import random
import matplotlib.pyplot as plt
import numpy as np
import time
import copy

import sphere as sp

#--------------------------------------------------
class SVRG(nn.Module):
    def __init__(self, x, Z, F_func, G_func, lr=1e-10):
        self.x = x
        self.Z = Z

        self.x_outer = x.clone()
        self.mu = torch.zeros(x.shape)
        self.F_func = F_func 
        self.G_func = G_func
        self.lr = lr
        
        self.epoch = -1

    def step(self, Zi, epoch, autograd=False, **extras):
        n_evals = 1

        # GET FULL MEAN IF NEEDED
        if epoch != self.epoch:
            self.mu = self.G_func(self.x, self.Z, autograd=autograd) / self.Z.shape[0]
            self.x_outer = self.x.clone()
            self.epoch = epoch

            n_evals += self.Z.shape[0]

        g_inner = self.G_func(self.x, Zi, autograd=autograd)
        g_outer = self.G_func(self.x_outer, Zi, autograd=autograd)

        V = g_inner - sp.Transport(g_outer - self.mu, None, self.x)
        self.x =sp.Exp(self.x, -self.lr * V)

        return n_evals


#--------------------------------------------------
class SGD(nn.Module):
    def __init__(self, x, Z, F_func, G_func, lr=1e-10):
        
        self.x = x
        self.Z = Z

        self.F_func = F_func 
        self.G_func = G_func
        self.lr = lr
        
        self.epoch = -1

    def step(self, Zi, epoch, autograd=False, **extras):
        n_evals = 1

        g = self.G_func(self.x, Zi, autograd=autograd)

        self.x =sp.Exp(self.x, -self.lr * g)

        return n_evals

#--------------------------------------------------
class SAGA(nn.Module):
    def __init__(self, x, Z, F_func, G_func, lr=1e-10):

        self.x_init = x.clone()

        self.x = x
        self.Z = Z

        self.mu = torch.zeros(x.shape)
        self.M = []
        for i in range(Z.shape[0]):
            self.M += [torch.zeros(x.shape)]

        self.F_func = F_func 
        self.G_func = G_func
        self.lr = lr
        
        self.epoch = -1

    def step(self, Zi, epoch, autograd=False, **extras):
        n_evals = 1
        i = extras["i"]
        n = self.Z.shape[0]

        Mi = self.M[i]
        g = self.G_func(self.x, Zi, autograd=autograd)

        V = g -sp.Transport(Mi - self.mu, None, self.x)
        self.x =sp.Exp(self.x, -self.lr * V)
        
        # Update previous grad and mean
        g =sp.Transport(g, None, self.x_init)
        self.mu += (1./n) * (g - Mi)
        self.M[i] = g.clone()

        # GET FULL MEAN IF NEEDED
        if epoch != self.epoch:
           
           self.epoch = epoch

        return n_evals
