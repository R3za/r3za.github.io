import torch
import torchvision
import torchvision.transforms as transforms
from torch.autograd import Variable, grad
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import random
import matplotlib.pyplot as plt
import numpy as np
import time
import copy
import sphere

#------- LEADING EIGENVECTOR OBJECTIVE
def Loss(x, Z):
    if isinstance(x, np.ndarray):
        x = torch.FloatTensor(x)
    if x.dim() == 1:
        x = x.unsqueeze(1)        
    if Z.dim() == 1:
        Z = Z.unsqueeze(0)

    A = Z.t().mm(Z)
   
    f = - x.t().mm(A.mm(x))

    n = float(Z.shape[0])
    return float(f) / n

def Gradient(x, Z, autograd=False):
    if Z.dim() == 1:
        Z = Z.unsqueeze(0)

    if autograd:
        x_tmp = Variable(x.data, requires_grad=True)
        F(x_tmp, Z).backward()

        return x_tmp.grad.data

    else:
        n = float(Z.shape[0])

        A = Z.t().mm(Z)
        G = - 2. * A.mm(x) / n
        
        return sphere.Proj(x, G)

def Lipschitz(Z):
    L = np.linalg.norm(Z, axis=1)

    return L

def assert_grad(x, Z):
    full = Gradient(x, Z)
    seq = torch.zeros(x.shape[0], 1)

    for i in range(Z.shape[0]):
        seq += Gradient(x, Z[i])

    np.testing.assert_almost_equal(full.numpy(), seq.numpy(),
     decimal=1)

## LEADING EIGEN
def leading_eigenvecor(Z):
    Z = np.asarray(Z)
    np.random.seed(1)
    eigh = np.linalg.eigh(Z.T.dot(Z))

    #assert False not in (eigh[0]>0)
    return eigh[1][:, -1]
