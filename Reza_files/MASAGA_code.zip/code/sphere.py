import torch
import torchvision
import torchvision.transforms as transforms
from torch.autograd import Variable, grad
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import random
import matplotlib.pyplot as plt
import numpy as np
import time
import copy


def Proj(x, H):
    return H - x.t().mm(H) * x


def Exp(x, U):
    U_norm = float(torch.norm(U))
    A = np.cos(U_norm) * x
    B = np.sin(U_norm) * U / U_norm

    return A + B

def Transport(U, x, y):
    return Proj(y, U)


# ----------------------------


