from torch.utils import data
import numpy as np
import torch

from sklearn.datasets import fetch_mldata
from sklearn.utils import shuffle



def A():
    # SET SEED
    np.random.seed(1)
    torch.manual_seed(1) 
    torch.cuda.manual_seed_all(1)


    n, d = 1000, 100
    Z = np.random.randint(1,100,n)[:,None]*np.random.rand(n, d) 
    

    Z = torch.FloatTensor(Z)

    return Z
    
def C():
    # SET SEED
    np.random.seed(1)
    torch.manual_seed(1) 
    torch.cuda.manual_seed_all(1)


    n, d = 10000, 1000
    Z = np.random.rand(n, d)
    Z = torch.FloatTensor(Z)

    return Z


def B():
    # SET SEED
    np.random.seed(1)
    torch.manual_seed(1) 
    torch.cuda.manual_seed_all(1)


    n, d = 10000, 1000
    Z = np.random.rand(n, d)
    Z = torch.FloatTensor(Z)

    return Z

def M(label):
    # SET SEED
    np.random.seed(1)
    torch.manual_seed(1) 
    torch.cuda.manual_seed_all(1)
    try:
        mnist = fetch_mldata('MNIST original', data_home="/mnt/home/issam/Datasets/")
    except:
        mnist = fetch_mldata('MNIST original')
    X, y = shuffle(mnist["data"], mnist["target"])
    X = X / 255.
    y = y

    ind = y == label
    X = X[ind][:2000]

    n, d = X.shape
    Z = X
    Z = torch.FloatTensor(X)

    return Z

# def B():
#     # SET SEED
#     np.random.seed(1)
#     torch.manual_seed(1) 
#     torch.cuda.manual_seed_all(1)


#     # DATASET - min loss 2.190
#     n, d = 100, 10
#     Z = torch.FloatTensor(np.random.rand(n, d))

#     r = np.random.rand(d,1)
#     x = torch.FloatTensor(r / np.linalg.norm(r))

#     return x, Z

#Dataset
class synthetic(data.Dataset):
    def __init__(self):
        bias = 1; scaling = 10; 
        sparsity = 10; solutionSparsity = 0.1;
        n = 100;
        p = 10;
        A = np.random.randn(n,p)+bias;
        A = A.dot(np.diag(scaling* np.random.randn(p)))
        A = A * (np.random.rand(n,p) < (sparsity*np.log(n)/n));
        w = np.random.randn(p) * (np.random.rand(p) < solutionSparsity);

        b = A.dot(w)


        self.X = A

        self.y = b[:, np.newaxis]
        self.n = A.shape[0]

    def __len__(self):
        return self.n

    def __getitem__(self, index):
        Xi = torch.FloatTensor(self.X[index])
        yi = torch.FloatTensor(self.y[index])

        return {"X":Xi, 
                "y":yi,
                "ind":index}



