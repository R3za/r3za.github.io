
import matplotlib
matplotlib.use('Agg')
import math
import torch
from matplotlib import pyplot as plt
import numpy as np
import numpy.random as npr
from scipy.stats import (multivariate_normal, norm, invwishart, )
from scipy.linalg import (sqrtm, )
from sklearn.utils import shuffle
import models as mo
import datasets as da
from torch.utils import data
import argparse
import torch.nn as nn
import models
from torch.autograd import Variable
import utils as ut
import sphere as sp
import loss_function

def sanity_checks(x, Z, loss_min):
    loss_init =  loss_function.Loss(x, Z)
    print("init/min: %.3f/%.3f" % (loss_init, loss_min))
    print("n: %d, d: %d" % (Z.shape[0], Z.shape[1]))
    assert loss_init > loss_min


def run(dataset_name, model_name, learning_rate, epochs, 
        sampling_method):
    #model_name = "saga"
    #learning_rate = 1e-10
    # SET SEED
    np.random.seed(1)
    torch.manual_seed(1) 
    torch.cuda.manual_seed_all(1)

    # DATASET
    if dataset_name == "A":
        Z = da.A()
    # DATASET
    if dataset_name == "M1":
        Z = da.M(label=1)
        
    if dataset_name == "M2":
        Z = da.M(label=2)

    if dataset_name == "M3":
        Z = da.M(label=3)

    if dataset_name == "M4":
        Z = da.M(label=4)

    if dataset_name == "B":
        Z = da.B()

    r = np.ones((Z.shape[1],1))
    x = torch.FloatTensor(r / np.linalg.norm(r))

    x_sol = loss_function.leading_eigenvecor(Z)
    loss_min = loss_function.Loss(x_sol, Z)
    sanity_checks(x, Z, loss_min)


    #assert_grad(x, Z)

    # MODEL
    if model_name == "sgd":
        model_class = models.SGD
    
    elif model_name == "svrg":
        model_class = models.SVRG

    elif model_name == "saga":
        model_class = models.SAGA

    model = model_class(x, Z, 
                        F_func=loss_function.Loss, 
                        G_func=loss_function.Gradient, 
                        lr=learning_rate)


    history = {"loss":[]}


    fname = ut.get_exp_path(dataset_name, model_name, 
        learning_rate, epochs, sampling_method)
    n = Z.shape[0]
    e = 0.
    n_iters = 0.
    
    nList = np.arange(n)

    if sampling_method == "uniform":
        P = nList / nList.sum()

    elif sampling_method == "lipschitz":
        P = loss_function.Lipschitz(Z)
        P = P / P.sum()



    while e < epochs:
        

        for _ in range(2*n):
            i = np.random.choice(nList, replace=True, p=P)

            n_evals = model.step(Z[i], epoch=e, autograd=False, i=i)
            #L += loss

            n_iters += n_evals
        
        e = n_iters / float(n)

        L =  (float((model.F_func(model.x, Z))) - float(loss_min)) / np.abs(float(loss_min))

        history["loss"] += [{"loss":L, "epoch":e}]


        print("Epoch: %d - %s - loss: %.3f" % 
             (e, ut.extract_fname(fname), L))

    ut.save_json(fname, history)


def get_parser():
    parser = argparse.ArgumentParser()

    parser.add_argument('-m','--model_name', default="svrg")
    parser.add_argument('-e','--epochs', default=10, type=int)
    parser.add_argument('-l','--learning_rate', default=1e-5, type=float)
    parser.add_argument('-d','--dataset_name')
    parser.add_argument('-s','--sampling_method', default="uniform")
    args = parser.parse_args()

    return args


if __name__ == "__main__":
    args = get_parser()



    run(args.dataset_name, args.model_name, 
        args.learning_rate, args.epochs, args.sampling_method)